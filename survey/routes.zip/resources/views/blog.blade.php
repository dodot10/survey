<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Blog</title>
</head>
<body>
    <a href="/">Home</a>
    <a href="/about">About</a>
    <a href="/blog">Blog</a>
    <a href="/contact">Contact</a>
    <article>
        <h3>Judul 1</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed optio aliquam ipsam. Tempore cupiditate maxime reiciendis itaque reprehenderit quas! Omnis reiciendis iure voluptates aspernatur at. Ratione eius voluptatem molestias aspernatur!</p>
    </article>

    <article>
        <h3>Judul 2</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur nam perferendis voluptatibus quos quaerat dignissimos, blanditiis id vel consectetur mollitia esse cumque laboriosam. Accusantium doloribus, voluptatem voluptatibus adipisci cupiditate facere?</p>
    </article>
</body>
</html>