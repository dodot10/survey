<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman contact</title>
</head>
<body>
    <a href="/">Home</a>
    <a href="/about">About</a>
    <a href="/blog">Blog</a>
    <a href="/contact">Contact</a>
    <h1>Halaman Contact</h1>
    <ul>
        <li>
            <a href="https://youtu.be/vDx6VA-6a6Y?si=a2HnEuAHkCck7G38">Youtube</a>
        </li>
    </ul>
</body>
</html>